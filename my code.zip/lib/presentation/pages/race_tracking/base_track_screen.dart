import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../data/models/participant.dart';
import '../../../data/models/segment_time.dart';
import '../../../services/navigation_service.dart';
import '../../../providers/participant_provider.dart';
import '../../../providers/segment_time_provider.dart';
import '../../../providers/result_provider.dart';
import '../../../providers/race_timer_provider.dart';
import '../../widgets/timer_section.dart';
import '../../widgets/search_bar_widget.dart';
import '../../widgets/participants_section.dart';
import '../../widgets/race_navigation_bar.dart';

abstract class BaseTrackScreenState<T extends StatefulWidget> extends State<T> {
  // Abstract properties
  String get title;
  IconData get icon;
  Segment get segment;

  // Search functionality
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = '';
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_onSearchChanged);

    // Load participants when screen initializes
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadParticipants();

      // Make sure timer is still running when coming to this screen
      final raceTimerProvider =
          Provider.of<RaceTimerProvider>(context, listen: false);
      if (!raceTimerProvider.isRunning) {
        raceTimerProvider.initialize();
      }
    });

    // Set up polling for updates
    _refreshTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (mounted) {
        _loadParticipants();
      }
    });
  }

  void _onSearchChanged() {
    setState(() {
      _searchQuery = _searchController.text;
    });
  }

  void _loadParticipants() {
    final segmentString = segment.toString().split('.').last;
    Provider.of<ParticipantProvider>(context, listen: false)
        .loadParticipantsBySegment(segmentString);
  }

  Future<void> _completeParticipantSegment(String id) async {
    // Use the global race timer instead of individual timer
    final raceTimerProvider =
        Provider.of<RaceTimerProvider>(context, listen: false);
    final participantProvider =
        Provider.of<ParticipantProvider>(context, listen: false);
    final segmentTimeProvider =
        Provider.of<SegmentTimeProvider>(context, listen: false);
    final resultProvider = Provider.of<ResultProvider>(context, listen: false);

    // Record current segment time using the global synchronized timer
    final currentTime = raceTimerProvider.getCurrentTime();

    // Record segment time in database
    final segmentTime = SegmentTime(
      participantId: id,
      segment: segment,
      time: currentTime,
      recordedAt: DateTime.now(),
    );
    await segmentTimeProvider.recordSegmentTime(segmentTime);

    // Update participant and move to next segment
    final updatedParticipant =
        await participantProvider.completeSegment(id, currentTime);

    if (updatedParticipant != null) {
      // Show transition message
      _showTransitionMessage(id, updatedParticipant.segment);

      // If all segments are completed, calculate final result
      if (updatedParticipant.isAllSegmentsCompleted) {
        await resultProvider.calculateAndUpdateResult(id);
      }
    }
  }

  void _showTransitionMessage(String participantId, String nextSegment) {
    final participantProvider =
        Provider.of<ParticipantProvider>(context, listen: false);
    final participants = participantProvider.participants;
    final participant = participants.firstWhere((p) => p.id == participantId,
        orElse: () => Participant(
            id: '',
            bib: 0,
            name: 'Participant',
            segment: '',
            completed: false));

    final name = participant.name;
    final nextSegmentName = nextSegment == 'swim'
        ? 'Swimming'
        : nextSegment == 'cycle'
            ? 'Cycling'
            : 'Finished';

    ScaffoldMessenger.of(context).hideCurrentSnackBar();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            '$name completed ${_getSegmentDisplayName()}. Next: $nextSegmentName'),
        backgroundColor: participant.completed ? Colors.green : Colors.blue,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 3),
        action: nextSegment.isNotEmpty && !participant.completed
            ? SnackBarAction(
                label: 'GO TO $nextSegmentName',
                onPressed: () {
                  final nextRoute =
                      NavigationService.getRouteForSegment(nextSegment);
                  if (nextRoute != null) {
                    Navigator.pushReplacementNamed(context, nextRoute);
                  }
                },
              )
            : null,
      ),
    );
  }

  String _getSegmentDisplayName() {
    switch (segment) {
      case Segment.run:
        return 'Running';
      case Segment.swim:
        return 'Swimming';
      case Segment.cycle:
        return 'Cycling';
      default:
        return 'Segment';
    }
  }

  void _navigateToPage(int index) {
    final currentIndex = NavigationService.getNavigationIndex(segment);
    if (index == currentIndex) return;

    Navigator.pushReplacementNamed(
        context, NavigationService.getRouteForIndex(index));
  }

  @override
  void dispose() {
    _searchController.dispose();
    _refreshTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 24),
            // Header section with title and icon
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '$title ',
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Icon(icon, size: 22),
              ],
            ),
            const SizedBox(height: 24),

            // Timer display - using synchronized race timer
            Consumer<RaceTimerProvider>(
              builder: (context, raceTimerProvider, _) {
                return TimerSection(
                  elapsed: raceTimerProvider.elapsed,
                  isRunning: raceTimerProvider.isRunning,
                  // Don't allow stopping the timer during the race
                  mode: TimerMode.viewOnly,
                );
              },
            ),

            const SizedBox(height: 24),

            // Search bar
            SearchBarWidget(controller: _searchController),

            const SizedBox(height: 16),

            // Participants list
            Consumer<ParticipantProvider>(
              builder: (context, participantProvider, _) {
                if (participantProvider.isLoading) {
                  return const Expanded(
                    child: Center(child: CircularProgressIndicator()),
                  );
                }

                if (participantProvider.error != null) {
                  return Expanded(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            participantProvider.error!,
                            style: TextStyle(color: Colors.red[700]),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton(
                            onPressed: _loadParticipants,
                            child: const Text('Retry'),
                          ),
                        ],
                      ),
                    ),
                  );
                }

                final filteredParticipants =
                    participantProvider.getFilteredParticipants(_searchQuery);

                if (filteredParticipants.isEmpty) {
                  return const Expanded(
                    child: Center(
                      child: Text('No participants found'),
                    ),
                  );
                }

                return ParticipantsSection(
                  participants: filteredParticipants,
                  onComplete: _completeParticipantSegment,
                );
              },
            ),
          ],
        ),
      ),
      bottomNavigationBar: RaceNavigationBar(
        currentIndex: NavigationService.getNavigationIndex(segment),
        onTap: _navigateToPage,
      ),
    );
  }
}

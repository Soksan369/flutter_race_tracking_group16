import 'package:flutter/material.dart';

class ListParticipants extends StatelessWidget {
  const ListParticipants({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
import 'dart:async';
import 'package:flutter/foundation.dart';
import '../data/services/firebase_http_service.dart';

class RaceTimerProvider with ChangeNotifier {
  final FirebaseHttpService _firebaseService;
  final String _raceId = 'race1'; // Default race

  DateTime? _startTime;
  Duration _elapsed = Duration.zero;
  Timer? _timer;
  bool _isRunning = false;

  RaceTimerProvider({FirebaseHttpService? firebaseService})
      : _firebaseService = firebaseService ?? FirebaseHttpService();

  Duration get elapsed => _elapsed;
  bool get isRunning => _isRunning;

  // Initialize - check if race is already started
  Future<void> initialize() async {
    try {
      final data = await _firebaseService.get('races/$_raceId');
      if (data != null &&
          data['startTime'] != null &&
          data['status'] == 'Started') {
        _startTime = DateTime.parse(data['startTime']);
        _startTimer();
      }
    } catch (e) {
      debugPrint('Error initializing timer: $e');
    }
  }

  // Start race timer - called from home screen
  Future<void> startRace() async {
    if (_isRunning) return;

    _startTime = DateTime.now();
    try {
      // Save start time to Firebase
      await _firebaseService.patch('races/$_raceId',
          {'startTime': _startTime!.toIso8601String(), 'status': 'Started'});
      _startTimer();
    } catch (e) {
      debugPrint('Error starting race: $e');
    }
  }

  // Reset race timer - stop and clear all timers
  Future<void> resetRace() async {
    if (!_isRunning) return;

    try {
      // Update status in Firebase
      await _firebaseService.patch('races/$_raceId', {'status': 'Reset'});

      // Reset local state
      _timer?.cancel();
      _timer = null;
      _startTime = null;
      _elapsed = Duration.zero;
      _isRunning = false;

      notifyListeners();
    } catch (e) {
      debugPrint('Error resetting race: $e');
    }
  }

  void _startTimer() {
    if (_startTime == null) return;

    _isRunning = true;

    // Initial calculation
    _updateElapsed();

    // Regular updates
    _timer = Timer.periodic(const Duration(milliseconds: 100), (_) {
      _updateElapsed();
    });

    notifyListeners();
  }

  void _updateElapsed() {
    if (_startTime != null) {
      _elapsed = DateTime.now().difference(_startTime!);
      notifyListeners();
    }
  }

  // Get current elapsed time (for segment completion)
  Duration getCurrentTime() {
    return _elapsed;
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}

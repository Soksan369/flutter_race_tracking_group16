import 'package:flutter/foundation.dart';
import '../data/models/result.dart';
import '../data/repositories/result_repository.dart';
import '../data/services/result_service.dart';
import '../data/services/segment_time_service.dart';
import '../data/models/segment_time.dart';

class ResultProvider with ChangeNotifier {
  final ResultRepository _repository;
  final ResultService _resultService;
  final SegmentTimeService _segmentTimeService;

  List<Result> _results = [];
  bool _isLoading = false;
  String? _error;

  ResultProvider({
    ResultRepository? repository,
    ResultService? resultService,
    SegmentTimeService? segmentTimeService,
  })  : _repository = repository ?? ResultRepository(),
        _resultService = resultService ?? ResultService(),
        _segmentTimeService = segmentTimeService ?? SegmentTimeService();

  List<Result> get results => _results;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> loadResults() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Load basic results first
      final data = await _repository.getResults();
      _results = data;

      // Then enrich them with segment times
      await _loadSegmentTimes();
    } catch (e) {
      _error = 'Failed to load results: $e';
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  // Load segment times for all participants
  Future<void> _loadSegmentTimes() async {
    for (int i = 0; i < _results.length; i++) {
      final result = _results[i];
      try {
        // Get all segment times for this participant
        final segmentTimes = await _segmentTimeService
            .getSegmentTimesForParticipant(result.participantId);

        // Create a new result with segment times
        Duration? runTime, swimTime, cycleTime;

        for (var segmentTime in segmentTimes) {
          switch (segmentTime.segment) {
            case Segment.run:
              runTime = segmentTime.time;
              break;
            case Segment.swim:
              swimTime = segmentTime.time;
              break;
            case Segment.cycle:
              cycleTime = segmentTime.time;
              break;
          }
        }

        // Replace result with enriched one
        _results[i] = Result(
          participantId: result.participantId,
          bib: result.bib,
          name: result.name,
          runTime: runTime,
          swimTime: swimTime,
          cycleTime: cycleTime,
          totalTime: result.totalTime,
          rank: result.rank,
        );
      } catch (e) {
        debugPrint(
            'Error loading segment times for ${result.participantId}: $e');
      }
    }
  }

  Future<void> calculateAndUpdateResult(String participantId) async {
    try {
      await _resultService.calculateAndUpdateResult(participantId);
      await loadResults(); // Refresh results after update
    } catch (e) {
      _error = 'Failed to update result: $e';
      notifyListeners();
    }
  }

  List<Result> getFilteredResults(String query, String category) {
    return _results.where((r) {
      // Search query filtering
      final matchesQuery = query.isEmpty ||
          r.name.toLowerCase().contains(query.toLowerCase()) ||
          r.bib.toString().contains(query);

      // Category filtering
      bool matchesCategory = true;
      if (category != 'All') {
        switch (category) {
          case 'Running':
            matchesCategory = r.runTime != null;
            break;
          case 'Swimming':
            matchesCategory = r.swimTime != null;
            break;
          case 'Cycling':
            matchesCategory = r.cycleTime != null;
            break;
        }
      }

      return matchesQuery && matchesCategory;
    }).toList();
  }
}
